/** 
Fork by Marvin Menzerath.
Original Project Copyright (c) 2010 Johan Nilsson
Licensed under the Apache License, Version 2.0
*/
package de.menzerath.actionbar.tutorial;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Button actionbar_home = (Button)findViewById(R.id.actionbarHome);
		Button actionbar_funk1 = (Button)findViewById(R.id.actionbarFunk1);
		Button actionbar_funk2 = (Button)findViewById(R.id.actionbarFunk2);
		final TextView actionbar_title = (TextView)findViewById(R.id.actionbarTxt);
		actionbar_funk1.setBackgroundResource(android.R.drawable.ic_menu_share);
		actionbar_funk2.setBackgroundResource(android.R.drawable.ic_menu_preferences);
		actionbar_title.setText("Action-Bar-Titel");
		actionbar_home.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		actionbar_funk2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				einToast();
			}
		});
		actionbar_funk1.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				einToast();
			}
		});
		
		Button buttonSetTitle = (Button)findViewById(R.id.button1);
		final EditText editTitle = (EditText)findViewById(R.id.editText1);
		buttonSetTitle.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				actionbar_title.setText(editTitle.getText().toString());
			}
		});
    }
    
    public void einToast() {
		Toast toast = Toast.makeText(this, "Ich bin nur ein kleiner Toast... :)", Toast.LENGTH_SHORT);
		toast.show();
	}
}